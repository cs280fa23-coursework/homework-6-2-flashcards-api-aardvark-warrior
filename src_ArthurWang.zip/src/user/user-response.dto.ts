export class UserResponseDTO {
  id: number;
  username: string;
}
